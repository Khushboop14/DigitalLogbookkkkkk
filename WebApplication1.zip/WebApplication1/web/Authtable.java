
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Authtable {
 public static void main(String[]args)
 {
     try
     {
      Class.forName("com.mysql.jdbc.Driver");
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
      PreparedStatement st = con.prepareStatement("insert into Authtable values(?,?,?,?)");
      
      Scanner sc = new Scanner(System.in);
      
      System.out.println("Enter ID");
      String id = sc.next();
      
      System.out.println("Enter password");
      String pwd = sc.next();
      
      System.out.println("post");
      String post = sc.next();    
      
      System.out.println("contact");
      String contact= sc.next();
      
      
      st.setString(1,id);
      st.setString (2,pwd);
      st.setString(3,post);
      st.setString(4,contact);
      
      st.executeUpdate();
      System.out.println("record inserted");
     }
     catch (SQLException |  ClassNotFoundException ex )
     {
      ex.printStackTrace();
     }
 }
}